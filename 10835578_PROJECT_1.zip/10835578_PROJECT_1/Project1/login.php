<?php
// Initialize the session to begin
session_start();
 
// First check if the user is already logged in, if yes then redirect him to the welcome page
if(isset($_SESSION["loggedin"]) && $_SESSION["loggedin"] === true){
    header("location: welcome.php");
    exit;
}

// Include config file
require_once "config.php";
 
// Define your variables and initialize with empty values
$username = $password = $confirm_password = "";
$username_err = $password_err = $confirm_password_err = "";
 
// Processing form data when form is submitted
if($_SERVER["REQUEST_METHOD"] == "POST"){
 
     // For checking if the username is empty
     if(empty(trim($_POST["username"]))){
        $username_err = "Please enter the username.";
    } else{
        $username = trim($_POST["username"]);
    }
    
    // For checking if the password is empty
    if(empty(trim($_POST["password"]))){
        $password_err = "Please enter your password.";
    } else{
        $password = trim($_POST["password"]);
    }
    
    // Validate credentials
    if(empty($username_err) && empty($password_err)){
        // Prepare a select statement
        $sql = "SELECT id, username, password FROM users WHERE username = ?";
        
        if($stmt = mysqli_prepare($link, $sql)){
            // Bind variables to the prepared statement as parameters
            mysqli_stmt_bind_param($stmt, "ss", $param_username, $param_password);
            
            // Set parameters
            $param_username = $username;
            $param_password = password_hash($password, PASSWORD_DEFAULT); // Creates a password hash
            
            // Attempt to execute the prepared statement
            if(mysqli_stmt_execute($stmt)){
                // Redirect to login page
                header("location: login.php");
            } else{
                echo "Something went wrong! Please try again.";
            }

            // Close the statement
            mysqli_stmt_close($stmt);
        }
    }
    
    // Close the connection
    mysqli_close($link);
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Log In</title>
    <link rel="stylesheet" href="style.css">
</head>
<body class = "body">
    <div class="wrap">       
         <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="POST">
            <h2>Log In</h2>

        <?php 
        if(!empty($login_err)){
            echo '<div class="error">' . $login_err . '</div><br><br>';
        }elseif(!empty($username_err)){
            echo '<span class="error">'. $username_err . '</span><br><br>';
        }elseif(!empty($password_err)){
            echo '<span class="error">'. $password_err . '</span><br><br>';
        }
        ?>
         <label>Username<br> <input type="text" name="username" class="inputbox <?php echo (!empty($username_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $username; ?>"><br><br></label>
                <label>Password<br> <input type="password" name="password" class="inputbox <?php echo (!empty($password_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $password; ?>"><br><br></label>
                <button type = "submit" class = "submit">Log In</button><br><br>
                <p>Don't have an account? <a href="signUp.php">Sign up now</a>.</p>
        </form>
    </div>
</body>`
</html>