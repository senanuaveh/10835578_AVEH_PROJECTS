<?php
// This initializes the session
session_start();
 
// This unsets all of the session variables
$_SESSION = array();
 
// This destroys the session.
session_destroy();
 
// This redirects to login page
header("location: login.php");
exit;
?>