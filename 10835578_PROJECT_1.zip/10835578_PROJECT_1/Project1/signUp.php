<?php
// config file must be included
require_once "config.php";

// Then you define variables and initialize with empty values
$username = $email = $password = $confirm_password = "";
$username_err = $email_err = $password_err = $confirm_password_err = "";

// Processing form data when form is submitted
if($_SERVER["REQUEST_METHOD"] == "POST"){

    // Validate the username
    if(empty(trim($_POST["username"]))){
        $username_err = "Please enter a username.";
    } else{
        // Then you prepare a select statement
        $sql = "SELECT id FROM users WHERE username = ?";
        
        if($stmt = mysqli_prepare($link, $sql)){
            // After bind variables to the prepared statement as parameters
            mysqli_stmt_bind_param($stmt, "s", $param_username);

            // Now set parameters
            $param_username = trim($_POST["username"]);

            // Then attempt to execute the prepared statement
            if(mysqli_stmt_execute($stmt)){

                //Store results
                mysqli_stmt_store_result($stmt);
                
                if(mysqli_stmt_num_rows($stmt) == 1){
                    $username_err = "This username is already taken.";
                } else{
                    $username = trim($_POST["username"]);
                }
            } else{
                echo "Oops! Something went wrong. Please try again.";
            }
            mysqli_stmt_close($stmt);
        }
    }

    // Validate email
    if(empty(trim($_POST["email"]))){
        $email_err = "Please enter an email.";
    } else{
        $sql = "SELECT id FROM users WHERE email = ?";
        
        if($stmt = mysqli_prepare($link, $sql)){
            mysqli_stmt_bind_param($stmt, "s", $param_email);
            $param_email = trim($_POST["email"]);
            if(mysqli_stmt_execute($stmt)){
                mysqli_stmt_store_result($stmt);
                
                if(mysqli_stmt_num_rows($stmt) == 1){
                    $email_err = "This email is already taken.";
                } else{
                    $email = trim($_POST["email"]);
                }
            } else{
                echo "Oops! Something went wrong. Please try again.";
            }
            mysqli_stmt_close($stmt);
        }
    }

    // Validate password
    if(empty(trim($_POST["password"]))){
        $password_err = "Please enter a password.";     
    } elseif(strlen(trim($_POST["password"])) < 6){
        $password_err = "Password must have atleast 6 characters.";
    } else{
        $password = trim($_POST["password"]);
    }

    // Validate confirm password
    if(empty(trim($_POST["confirm_password"]))){
        $confirm_password_err = "Please confirm password.";     
    } else{
        $confirm_password = trim($_POST["confirm_password"]);
        if(empty($password_err) && ($password != $confirm_password)){
            $confirm_password_err = "Passwords did not match.";
        }
    }
    
    // Check for input errors before inserting in database
    if(empty($username_err) && empty($password_err) && empty($confirm_password_err && empty($email_error))){

        // Prepare an insert statement
        $sql = "INSERT INTO users (username, password, email) VALUES (?, ?)";
         
        if($stmt = mysqli_prepare($link, $sql)){

            // Bind variables to the prepared statement as parameters
            mysqli_stmt_bind_param($stmt, "ss", $param_username, $param_password, $param_email);
            
            // Set parameters
            $param_username = $username;
            $param_password = password_hash($password, PASSWORD_DEFAULT);
            $param_email = $email;

            // Attempt to execute the prepared statement
            if(mysqli_stmt_execute($stmt)){
                // Redirect to login page
                header("location: login.php");
            } else{
                echo "Please try again later.";
            }
            // Close statement
            mysqli_stmt_close($stmt);
        }
    }
    // Close connection
    mysqli_close($link);
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Sign Up Page</title>
    <link rel="stylesheet" href="style.css">
</head>
<body class = "body">
    <div class="wrap">
        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="POST">
            <h2>Sign Up Here</h2>
            <p>Provide the required details to create your account</p><hr><br>
            <?php
            if(!empty($username_err)){
                echo '<span class="error">'. $username_err . '</span><br><br>';
            }elseif(!empty($email_err)){
                echo '<span class="error">'. $email_err . '</span><br><br>';
            }elseif(!empty($password_err)){
            echo '<span class="error">'. $password_err . '</span><br><br>';
            }elseif(!empty($confirm_password_err)){
                echo '<span class="error">'. $confirm_password_err . '</span><br><br>';
            }
            ?>
                <label>Username<br> <input type="text" name="username" class="inputbox <?php echo (!empty($username_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $username; ?>"><br></label>
                <label>Email<br> <input type ="email" name="email" class="inputbox <?php echo (!empty($email_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $email; ?>"><br></label>
                <span class="err"><?php echo $username_err; ?></span><br>
                <label>Password<br> <input type="password" name="password" class="inputbox <?php echo (!empty($password_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $password; ?>"><br></label>
                <span class="err"><?php echo $password_err; ?></span><br>
                <label>Confirm Password<br><input type="password" name="confirm_password" class="inputbox <?php echo (!empty($confirm_password_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $confirm_password; ?>"><br></label>
                <span class="err"><?php echo $confirm_password_err; ?></span><br><br>
                <input type="checkbox">Click here to receive updates via email</input><br>
                <button type = "submit" class = "submit">Submit</button>
                <button type= "reset" class = "reset">Reset</button><br><br>
                <p>Already a member? You can <a href="login.php">Login here</a>.</p>
        </form>
    </div>
</body>
</html>