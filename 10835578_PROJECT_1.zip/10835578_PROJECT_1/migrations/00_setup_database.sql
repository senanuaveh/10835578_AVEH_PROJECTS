/* ========= CREATE DATABASE ========= */
CREATE DATABASE `project_db`;

/* ========= SELECT DATABASE ========= */

USE `project_db`;